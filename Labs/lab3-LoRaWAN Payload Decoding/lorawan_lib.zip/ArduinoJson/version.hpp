// ArduinoJson - arduinojson.org
// Copyright Benoit Blanchon 2014-2019
// MIT License

#pragma once

#define ARDUINOJSON_VERSION "6.12.0"
#define ARDUINOJSON_VERSION_MAJOR 6
#define ARDUINOJSON_VERSION_MINOR 12
#define ARDUINOJSON_VERSION_REVISION 0
